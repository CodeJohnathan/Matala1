# matalot
for the second task I created 2 new calsses, "wpoint" for algoritem 1 and "finder" for algoritem 2.
for your conftable I put from the main all the old code into a note.
for algoritem 2 I create a readind from "c/wigle_wifi" of "lost" and "have", and the answer is called "lost1"
for  algoritem 1 I dident make a call, becuse I didnt know how and from where I suppoust to do that. but it is very easy to prefer.

I hope the my teamade will finnish the chacking very soon, so I will be able to upload it too.

Iwm very sorry for the little late, it was becuse of private family things..
good luck!
